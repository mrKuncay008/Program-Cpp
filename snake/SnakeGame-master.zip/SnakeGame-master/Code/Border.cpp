#include "Border.h"



Border::Border(sf::Vector2f position, sf::Texture * texture) :
	Entity(position, texture)
{
}


Border::~Border()
{
}


//Update Function for the Border 
void Border::update(double deltaT)
{

}