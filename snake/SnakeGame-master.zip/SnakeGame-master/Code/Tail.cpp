#include "Tail.h"



Tail::Tail(sf::Vector2f position, sf::Texture * texture) :
	Entity(position,texture)
{
}


Tail::~Tail()
{
}


void Tail::update(double deltaT)
{
	
}