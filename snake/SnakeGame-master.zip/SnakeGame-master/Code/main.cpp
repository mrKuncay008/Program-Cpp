#include <iostream>
#include "Game.h"


/*
	Things todo:

	- Also Figure out a away to PlayAgain in the LostState
*/

int main()
{
	Game snakeGame;

	snakeGame.start();

	return 0;
}